
import { useEffect, useState } from 'react';
// Helper to get holiday name for a date
function getHolidayName(holidays, date) {
  const d = date.toISOString().split('T')[0];
  const h = holidays.find(h => h.date === d);
  return h ? h.localName || h.name : '';
}
import './App.css';

const COUNTRIES = [
  { code: 'US', name: 'United States' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'IN', name: 'India' },
  { code: 'DE', name: 'Germany' },
  { code: 'JP', name: 'Japan' },
  // Add more as needed
];

const getMonthName = (date) => date.toLocaleString('default', { month: 'long' });

function getQuarter(month) {
  return Math.floor(month / 3) + 1;
}

function areConsecutive(dates) {
  if (dates.length < 2) return false;
  dates.sort((a, b) => a - b);
  for (let i = 1; i < dates.length; i++) {
    if ((dates[i] - dates[i - 1]) !== 1) return false;
  }
  return true;
}

function App() {
  const today = new Date();
  const [country, setCountry] = useState('US');
  const [view, setView] = useState('month'); // 'month' or 'quarter'
  const [currentDate, setCurrentDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [holidays, setHolidays] = useState([]);
  const [loading, setLoading] = useState(false);
  const [holidayInfo, setHolidayInfo] = useState({ show: false, name: '', x: 0, y: 0 });
  const [showOnlyHolidayWeeks, setShowOnlyHolidayWeeks] = useState(false);

  useEffect(() => {
    let ignore = false;
    async function fetchHolidays() {
      setLoading(true);
      const year = currentDate.getFullYear();
      let data = [];
      try {
        if (country === 'IN' && year === 2025) {
          const jsonUrl = new URL('./holidays_india_2025.json', import.meta.url).href;
          const res = await fetch(jsonUrl);
          data = await res.json();
        } else {
          const url = `https://date.nager.at/api/v3/PublicHolidays/${year}/${country}`;
          const res = await fetch(url);
          data = await res.json();
        }
      } catch (e) {
        data = [];
      }
      if (!ignore) setHolidays(data);
      setLoading(false);
    }
    fetchHolidays();
    return () => { ignore = true; };
  }, [country, currentDate.getFullYear()]);

  // Get visible months
  let months = [];
  if (view === 'month') {
    months = [currentDate.getMonth()];
  } else {
    const q = getQuarter(currentDate.getMonth());
    months = [0, 1, 2].map(i => (q - 1) * 3 + i);
  }

  const year = currentDate.getFullYear();

  function handlePrev() {
    if (view === 'month') {
      setCurrentDate(new Date(year, currentDate.getMonth() - 1, 1));
    } else {
      setCurrentDate(new Date(year, currentDate.getMonth() - 3, 1));
    }
  }
  function handleNext() {
    if (view === 'month') {
      setCurrentDate(new Date(year, currentDate.getMonth() + 1, 1));
    } else {
      setCurrentDate(new Date(year, currentDate.getMonth() + 3, 1));
    }
  }

  function getHolidaysForMonth(month) {
    return holidays.filter(h => {
      const d = new Date(h.date);
      return d.getMonth() === month;
    });
  }

  function renderCalendar(month) {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const numDays = lastDay.getDate();
    const startDay = firstDay.getDay();
    const monthHolidays = getHolidaysForMonth(month).filter(h => new Date(h.date).getDay() !== 0);
    const holidayDates = monthHolidays.map(h => new Date(h.date).getDate());

    // Build weeks
    let weeks = [];
    let week = [];
    let dayNum = 1 - startDay;
    while (dayNum <= numDays) {
      week = [];
      for (let i = 0; i < 7; i++) {
        if (dayNum > 0 && dayNum <= numDays) {
          week.push(dayNum);
        } else {
          week.push(null);
        }
        dayNum++;
      }
      weeks.push(week);
    }

    return (
      <div className="calendar-block" key={month}>
        <h2>{getMonthName(new Date(year, month, 1))} {year}</h2>
        <table className="calendar-table">
          <thead>
            <tr>
              <th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
            </tr>
          </thead>
          <tbody>
            {weeks.map((week, i) => {
              const hols = week.filter(d => d && holidayDates.includes(d));
              if (showOnlyHolidayWeeks && hols.length === 0) return null;
              let rowClass = '';
              if (hols.length > 1) rowClass = 'dark-green';
              else if (hols.length === 1) rowClass = 'light-green';
              return (
                <tr key={i} className={rowClass}>
                  {week.map((d, j) => {
                    const isHoliday = d && holidayDates.includes(d);
                    let holidayName = '';
                    if (isHoliday && d) {
                      const dateObj = new Date(year, month, d);
                      holidayName = getHolidayName(monthHolidays, dateObj);
                    }
                    return (
                      <td key={j} className={isHoliday ? 'holiday' : ''}>
                        <div style={{position:'relative', minHeight:'2.5em'}}>
                          {isHoliday && d ? (
                            <span
                              style={{ color: '#e53935', fontWeight: 'bold', cursor: 'pointer' }}
                              title={holidayName}
                              onClick={e => {
                                e.stopPropagation();
                                const rect = e.target.getBoundingClientRect();
                                setHolidayInfo({
                                  show: true,
                                  name: holidayName,
                                  x: rect.left + window.scrollX,
                                  y: rect.bottom + window.scrollY
                                });
                              }}
                            >{d}</span>
                          ) : (d || '')}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div className="vacation-calendar" onClick={() => setHolidayInfo({ show: false, name: '', x: 0, y: 0 })}>
      <h1>Vacation Calendar</h1>
      <div className="controls">
        <select value={country} onChange={e => setCountry(e.target.value)}>
          {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}
        </select>
        <button onClick={() => setView('month')} className={view === 'month' ? 'active' : ''}>Monthly</button>
        <button onClick={() => setView('quarter')} className={view === 'quarter' ? 'active' : ''}>Quarterly</button>
        <button onClick={handlePrev}>&lt;</button>
        <button onClick={handleNext}>&gt;</button>
        <button onClick={() => setShowOnlyHolidayWeeks(v => !v)} className={showOnlyHolidayWeeks ? 'active' : ''}>
          {showOnlyHolidayWeeks ? 'Show All Weeks' : 'Show Only Holiday Weeks'}
        </button>
      </div>
      {loading ? <p>Loading holidays...</p> : (
        <div className="calendar-container">
          {months.map(m => renderCalendar(m))}
        </div>
      )}
      <div className="legend">
  <span className="legend-box light-green"></span> 1 Holiday in week
  <span className="legend-box dark-green"></span> &gt;1 Holiday in week
      </div>
      {holidayInfo.show && (
        <div
          className="holiday-popup"
          style={{
            position: 'absolute',
            left: holidayInfo.x,
            top: holidayInfo.y + 8,
            background: '#fff',
            border: '1px solid #ccc',
            borderRadius: '8px',
            padding: '0.7em 1.2em',
            zIndex: 1000,
            boxShadow: '0 2px 12px rgba(0,0,0,0.12)'
          }}
        >
          <b>Holiday:</b> {holidayInfo.name}
        </div>
      )}
    </div>
  );
}

export default App;
